from django.apps import AppConfig


class LogregAppConfig(AppConfig):
    name = 'logreg_app'
